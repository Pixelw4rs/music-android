# Limusic for Android

A lightweight YouTube Music player for Android, styled after the desktop Limusic.
Kotlin + Jetpack Compose + Media3 (ExoPlayer) + NewPipeExtractor. GPL-3.0.

**Features:** song search · background playback with notification and lock-screen controls ·
queue (next / previous / seek) · favorites saved on the device · mini player + full player ·
English and German.

Not included (yet): account sign-in, playlists, lyrics, scrobbling, Listen Together.

## Build the APK

### Option A: GitHub (no setup)
1. Create a new GitHub repository and upload everything in this folder.
2. Open the **Actions** tab → **Build APK** → wait for the green check.
3. Download `limusic-debug-apk` from the run and install the `.apk` on your phone
   (allow "install unknown apps" for your browser/files app).

### Option B: Android Studio
Open this folder in Android Studio (Ladybug or newer), let it sync, press **Run**,
or use **Build → Build APK(s)**. Command line: `./gradlew assembleDebug` →
`app/build/outputs/apk/debug/app-debug.apk`.

## If something breaks
- **Search/playback suddenly fails:** YouTube changes often. Bump the NewPipeExtractor version in
  `app/build.gradle.kts` (`com.github.TeamNewPipe:NewPipeExtractor:v0.24.6`) to the latest release
  from https://github.com/TeamNewPipe/NewPipeExtractor/releases.
- **Build error about versions:** update the plugin versions in the root `build.gradle.kts`.

## Layout
- `data/` – YouTube search + stream lookup, OkHttp bridge, favorites
- `player/PlaybackService.kt` – ExoPlayer in a foreground media service
- `player/MusicViewModel.kt` – connects the UI to the service
- `ui/` – Compose screens and theme
