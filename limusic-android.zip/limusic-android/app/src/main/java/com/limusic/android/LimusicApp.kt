package com.limusic.android

import android.app.Application
import com.limusic.android.data.OkHttpDownloader
import org.schabi.newpipe.extractor.NewPipe

class LimusicApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // NewPipeExtractor needs an HTTP client before any YouTube call. Also runs when the
        // playback service is started on its own, because Application.onCreate always runs first.
        NewPipe.init(OkHttpDownloader())
    }
}
