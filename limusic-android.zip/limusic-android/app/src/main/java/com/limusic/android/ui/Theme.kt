package com.limusic.android.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Accent taken from the desktop Limusic's lime green.
private val Accent = Color(0xFFA4C400)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF111111),
    primaryContainer = Color(0xFF2E3800),
    onPrimaryContainer = Color(0xFFD8F25A),
    background = Color(0xFF121212),
    onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF121212),
    onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF242424),
    onSurfaceVariant = Color(0xFFB5B5B5),
    surfaceContainer = Color(0xFF1C1C1C),
    secondaryContainer = Color(0xFF2E3800),
    onSecondaryContainer = Color(0xFFD8F25A),
)

@Composable
fun LimusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
