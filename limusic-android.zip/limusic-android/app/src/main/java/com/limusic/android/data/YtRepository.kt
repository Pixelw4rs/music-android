package com.limusic.android.data

import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

object YtRepository {

    private val youtube get() = ServiceList.YouTube
    private val idRegex = Regex("[?&]v=([A-Za-z0-9_-]{11})")

    /** Searches YouTube Music, songs only. */
    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        val handler = youtube.searchQHFactory.fromQuery(
            query,
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS),
            "",
        )
        val info = SearchInfo.getInfo(youtube, handler)
        info.relatedItems
            .filterIsInstance<StreamInfoItem>()
            .mapNotNull { it.toTrack() }
    }

    private fun StreamInfoItem.toTrack(): Track? {
        val id = idRegex.find(url)?.groupValues?.get(1) ?: return null
        val thumb = thumbnails.maxByOrNull { it.height }?.url
        return Track(
            id = id,
            title = name,
            artist = uploaderName.orEmpty(),
            durationSec = duration,
            thumbnail = thumb,
        )
    }

    // ---- stream URL resolution (blocking; called from ExoPlayer's loading thread) ----

    private class Cached(val url: String, val expiresAt: Long)

    private val urlCache = ConcurrentHashMap<String, Cached>()

    /**
     * Returns a direct audio URL for a video id. Results are cached because ExoPlayer asks again
     * for every seek / range request.
     */
    @Throws(IOException::class)
    fun resolveAudioUrl(videoId: String): String {
        val now = System.currentTimeMillis()
        urlCache[videoId]?.let { if (it.expiresAt > now) return it.url }

        try {
            val info = StreamInfo.getInfo(youtube, "https://www.youtube.com/watch?v=$videoId")
            val candidates: List<AudioStream> = info.audioStreams.filter {
                it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP
            }
            // M4A (AAC) seeks most reliably; fall back to anything else (WebM/Opus).
            val best = candidates.filter { it.format == MediaFormat.M4A }.maxByOrNull { it.averageBitrate }
                ?: candidates.maxByOrNull { it.averageBitrate }
                ?: throw IOException("No playable audio stream for $videoId")

            urlCache[videoId] = Cached(best.content, now + 60 * 60 * 1000L) // YouTube URLs live ~6h
            return best.content
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException("Could not load stream: ${e.message}", e)
        }
    }
}
