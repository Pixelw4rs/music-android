package com.limusic.android.player

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.limusic.android.data.FavoritesStore
import com.limusic.android.data.Track
import com.limusic.android.data.YtRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlayerUi(
    val hasMedia: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val artwork: String? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
    val skippedBecauseOfError: Boolean = false,
)

data class SearchUi(
    val query: String = "",
    val results: List<Track> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
)

class MusicViewModel(app: Application) : AndroidViewModel(app) {

    private var controller: MediaController? = null

    private val _player = MutableStateFlow(PlayerUi())
    val player: StateFlow<PlayerUi> = _player.asStateFlow()

    private val _search = MutableStateFlow(SearchUi())
    val search: StateFlow<SearchUi> = _search.asStateFlow()

    private val favoritesStore = FavoritesStore(app)
    val favorites: StateFlow<List<Track>> = favoritesStore.items

    /** Everything we have seen, so the player screen can map a media id back to a Track. */
    private val known = mutableMapOf<String, Track>()
    private var searchJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh(clearSkipNotice = events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION))
        }

        override fun onPlayerError(error: PlaybackException) {
            val c = controller ?: return
            if (c.hasNextMediaItem()) {
                _player.update { it.copy(skippedBecauseOfError = true) }
                c.seekToNextMediaItem()
                c.prepare()
                c.play()
            }
        }
    }

    init {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = try {
                future.get()
            } catch (e: Exception) {
                return@addListener
            }
            controller = c
            c.addListener(listener)
            refresh()
        }, ContextCompat.getMainExecutor(context))

        // Progress bar ticker
        viewModelScope.launch {
            while (true) {
                delay(500)
                val c = controller ?: continue
                if (c.isPlaying) {
                    _player.update {
                        it.copy(
                            positionMs = c.currentPosition.coerceAtLeast(0),
                            durationMs = c.duration.takeIf { d -> d != C.TIME_UNSET } ?: it.durationMs,
                        )
                    }
                }
            }
        }
    }

    private fun refresh(clearSkipNotice: Boolean = false) {
        val c = controller ?: return
        val item = c.currentMediaItem
        val md = item?.mediaMetadata
        _player.update {
            it.copy(
                hasMedia = item != null,
                mediaId = item?.mediaId,
                title = md?.title?.toString().orEmpty(),
                artist = md?.artist?.toString().orEmpty(),
                artwork = md?.artworkUri?.toString(),
                isPlaying = c.isPlaying,
                isBuffering = c.playbackState == Player.STATE_BUFFERING,
                positionMs = c.currentPosition.coerceAtLeast(0),
                durationMs = c.duration.takeIf { d -> d != C.TIME_UNSET } ?: 0,
                hasNext = c.hasNextMediaItem(),
                hasPrevious = c.hasPreviousMediaItem(),
                skippedBecauseOfError = if (clearSkipNotice) false else it.skippedBecauseOfError,
            )
        }
    }

    // ---- search ----

    fun setQuery(q: String) = _search.update { it.copy(query = q) }

    fun search() {
        val q = _search.value.query.trim()
        if (q.isEmpty()) return
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _search.update { it.copy(loading = true, error = null) }
            try {
                val results = YtRepository.search(q)
                results.forEach { known[it.id] = it }
                _search.update { it.copy(results = results, loading = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _search.update { it.copy(loading = false, error = e.message ?: e.javaClass.simpleName) }
            }
        }
    }

    // ---- playback ----

    fun play(tracks: List<Track>, startIndex: Int) {
        val c = controller ?: return
        tracks.forEach { known[it.id] = it }
        c.setMediaItems(tracks.map(::toMediaItem), startIndex, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun previous() {
        val c = controller ?: return
        // Like most players: restart the song first, go to the previous one on a second tap.
        if (c.currentPosition > 3000 || !c.hasPreviousMediaItem()) c.seekTo(0) else c.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        _player.update { it.copy(positionMs = positionMs) }
    }

    // ---- favorites ----

    fun toggleFavorite(track: Track) = favoritesStore.toggle(track)

    fun currentTrack(): Track? = _player.value.mediaId?.let { known[it] }

    private fun toMediaItem(t: Track): MediaItem =
        MediaItem.Builder()
            .setMediaId(t.id)
            .setUri("limusic://track/${t.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artist)
                    .setArtworkUri(t.thumbnail?.let { Uri.parse(it) })
                    .build(),
            )
            .build()

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
