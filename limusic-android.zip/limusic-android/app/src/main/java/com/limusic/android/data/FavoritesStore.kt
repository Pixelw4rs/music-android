package com.limusic.android.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Favorites kept on the device (SharedPreferences, JSON). */
class FavoritesStore(context: Context) {

    private val prefs = context.getSharedPreferences("limusic", Context.MODE_PRIVATE)
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<Track>> = _items.asStateFlow()

    fun toggle(track: Track) {
        val current = _items.value
        _items.value =
            if (current.any { it.id == track.id }) current.filterNot { it.id == track.id }
            else listOf(track) + current
        save()
    }

    private fun load(): List<Track> = try {
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Track(
                id = o.getString("id"),
                title = o.getString("title"),
                artist = o.optString("artist"),
                durationSec = o.optLong("dur"),
                thumbnail = o.optString("thumb").ifBlank { null },
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun save() {
        val arr = JSONArray()
        _items.value.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("artist", it.artist)
                    .put("dur", it.durationSec)
                    .put("thumb", it.thumbnail ?: ""),
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object {
        const val KEY = "favorites"
    }
}
